﻿Public Class frmZip
    Private Sub btnHarrison_Click(sender As Object, e As EventArgs) Handles btnHarrison.Click
        lblZip.Text = "45030"
    End Sub

    Private Sub btnNorwood_Click(sender As Object, e As EventArgs) Handles btnNorwood.Click
        lblZip.Text = "45212"
    End Sub

    Private Sub btnErlanger_Click(sender As Object, e As EventArgs) Handles btnErlanger.Click
        lblZip.Text = "41017"
    End Sub

    Private Sub btnFlorence_Click(sender As Object, e As EventArgs) Handles btnFlorence.Click
        lblZip.Text = "41042"
    End Sub

    Private Sub btnLawrenceburg_Click(sender As Object, e As EventArgs) Handles btnLawrenceburg.Click
        lblZip.Text = "47025"
    End Sub

    Private Sub btnRisingSun_Click(sender As Object, e As EventArgs) Handles btnRisingSun.Click
        lblZip.Text = "47040"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
