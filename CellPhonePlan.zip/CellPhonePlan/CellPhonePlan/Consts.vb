﻿Public Class Consts
    Public Const dblTaxRate As Double = 0.06
    Public Const dblEightHundred As Double = 45
    Public Const dblFifteenHundred As Double = 65
    Public Const dblUnlimitedTalk As Double = 99
    Public Const dblEmail As Double = 25
    Public Const dblTexting As Double = 10
    Public Const dblModel100 As Double = 29.95
    Public Const dblModel110 As Double = 49.95
    Public Const dblModel200 As Double = 99.95
End Class
