﻿Public Class Consts
    Public Const AnnualPayments As Integer = 12
    Public Const UtilitySurcharge As Double = 1.2
    Public Const ParkingSurcharge As Double = 50
    Public Const RentPercent As Double = 0.1
End Class
